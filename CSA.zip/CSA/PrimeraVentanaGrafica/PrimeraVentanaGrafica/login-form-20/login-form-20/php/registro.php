<?php
// Configuración de la conexión
$servidor = "localhost";
$usuario_db = "root";
$password_db = "";
$db_nombre = "licoreria";

$link = mysqli_connect($servidor, $usuario_db, $password_db, $db_nombre);
mysqli_set_charset($link, "utf8");

if (!$link) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Procesar el registro si vienen datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturamos los datos enviados desde Java o Web
    $nombre = mysqli_real_escape_string($link, $_POST['NombreCompleto']);
    $pass   = mysqli_real_escape_string($link, $_POST['contrasena']);
    // ✅ Vuelve a recibir el cargo desde el desplegable
    $cargo  = isset($_POST['cargo']) ? mysqli_real_escape_string($link, $_POST['cargo']) : 'Empleado';

    $sql = "INSERT INTO usuario (nombre, contrasena, cargo) VALUES ('$nombre', '$pass', '$cargo')";
    
    if (mysqli_query($link, $sql)) {
        echo "Registro exitoso";
    } else {
        echo "Error: " . mysqli_error($link);
    }
}
mysqli_close($link);
?>