import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class usuario extends JPanel implements ActionListener {

    private static final long serialVersionUID = 1L;

    private String cargoUsuario;

    private JButton btnLicoresRegistro;
    private JButton btnLicoresVencidos;
    private JButton btnRefrescosRegistro;
    private JButton btnRefrescosVencidos;
    private JButton btnSalir;

    public usuario(String cargo) {
        this.cargoUsuario = cargo;

        setLayout(null);
        setBackground(new Color(245, 245, 245));

        // Título
        JLabel lblTitulo = new JLabel("PANEL DE EMPLEADO", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Rockwell Condensed", Font.BOLD, 28));
        lblTitulo.setForeground(new Color(40, 40, 40));
        lblTitulo.setBounds(0, 40, 620, 40);
        add(lblTitulo);

        JLabel lblSub = new JLabel("Selecciona una opción:", SwingConstants.CENTER);
        lblSub.setFont(new Font("Tahoma", Font.PLAIN, 14));
        lblSub.setForeground(new Color(100, 100, 100));
        lblSub.setBounds(0, 85, 620, 25);
        add(lblSub);

        JSeparator sep = new JSeparator();
        sep.setBounds(80, 120, 460, 2);
        sep.setForeground(new Color(180, 180, 180));
        add(sep);

        // Sección LICORES
        JLabel lblLicores = new JLabel("  LICORES");
        lblLicores.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblLicores.setForeground(new Color(80, 80, 80));
        lblLicores.setBounds(150, 132, 300, 18);
        add(lblLicores);

        btnLicoresRegistro = crearBoton(
                "REGISTRO DE LICORES",
                "/imagenes/32officeicons-15_89722.png",
                new Color(131, 174, 222)
        );
        btnLicoresRegistro.setBounds(150, 155, 320, 60);
        add(btnLicoresRegistro);

        btnLicoresVencidos = crearBoton(
                "LICORES VENCIDOS",
                "/imagenes/1-trash-cat_icon-icons.com_76677.png",
                new Color(100, 149, 200)
        );
        btnLicoresVencidos.setBounds(150, 225, 320, 60);
        add(btnLicoresVencidos);

        // Sección REFRESCOS
        JLabel lblRefrescos = new JLabel("  REFRESCOS");
        lblRefrescos.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblRefrescos.setForeground(new Color(80, 80, 80));
        lblRefrescos.setBounds(150, 302, 300, 18);
        add(lblRefrescos);

        btnRefrescosRegistro = crearBoton(
                "REGISTRO DE REFRESCOS",
                "/imagenes/32officeicons-3_89720.png",
                new Color(172, 210, 172)
        );
        btnRefrescosRegistro.setBounds(150, 325, 320, 60);
        add(btnRefrescosRegistro);

        btnRefrescosVencidos = crearBoton(
                "REFRESCOS VENCIDOS",
                "/imagenes/1485477072-check_78599.png",
                new Color(130, 180, 130)
        );
        btnRefrescosVencidos.setBounds(150, 395, 320, 60);
        add(btnRefrescosVencidos);

        // Separador inferior
        JSeparator sepInf = new JSeparator();
        sepInf.setBounds(80, 480, 460, 2);
        sepInf.setForeground(new Color(180, 180, 180));
        add(sepInf);

        // Botón Salir
        btnSalir = new JButton("SALIR");
        btnSalir.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnSalir.setBackground(new Color(220, 80, 80));
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setFocusPainted(false);
        btnSalir.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        btnSalir.setBounds(240, 498, 140, 38);
        btnSalir.addActionListener(this);
        add(btnSalir);
    }

    private JButton crearBoton(String texto, String rutaIcono, Color fondo) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Rockwell Condensed", Font.BOLD, 16));
        btn.setBackground(fondo);
        btn.setForeground(new Color(30, 30, 30));
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(fondo.darker(), 1),
                new EmptyBorder(0, 20, 0, 0)
        ));
        try {
            ImageIcon icon = new ImageIcon(usuario.class.getResource(rutaIcono));
            Image img = icon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH);
            btn.setIcon(new ImageIcon(img));
            btn.setIconTextGap(15);
        } catch (Exception ignored) {}
        btn.addActionListener(this);
        return btn;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object ob = e.getSource();

        if (ob.equals(btnSalir)) {
            System.exit(0);
        }

        if (ob.equals(btnLicoresRegistro)) {
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            frame.setContentPane(new licores_registro(null, cargoUsuario));
            frame.revalidate();
            frame.repaint();
        }

        if (ob.equals(btnLicoresVencidos)) {
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            frame.setContentPane(new licores_vencidos(cargoUsuario));
            frame.revalidate();
            frame.repaint();
        }

        if (ob.equals(btnRefrescosRegistro)) {
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            frame.setContentPane(new refrescos_registro(null, cargoUsuario));
            frame.revalidate();
            frame.repaint();
        }

        if (ob.equals(btnRefrescosVencidos)) {
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            frame.setContentPane(new refrescos_vencidos(cargoUsuario));
            frame.revalidate();
            frame.repaint();
        }
    }
}
