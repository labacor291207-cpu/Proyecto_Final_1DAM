import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import BaseDatos.Conexion;
import BaseDatos.GestionBaseDatos;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class solicitudes_compra extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JLabel lblSolicitudes;
	private JScrollPane scrollPane;
	private String [] datos = new String [8];
	private DefaultTableModel modelo;
	private JButton btnSalir;
	private JButton btnVolver;
	private JButton btnEliminar;
	
	/**
	 * Create the panel.
	 */
		
	public solicitudes_compra(DefaultTableModel modelo) {
		setLayout(null);
		
		 this.modelo = new DefaultTableModel(
				    new String[]{"ID", "PRODUCTO", "CANTIDAD", "TIPO", "FECHA", "PROVEEDOR", "ESTADO", "MONTO T."}, 0
				);
		
		lblSolicitudes = new JLabel("SOLICITUDES DE COMPRA");
		lblSolicitudes.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 24));
		lblSolicitudes.setBounds(170, 41, 268, 26);
		add(lblSolicitudes);
		
		table = new JTable(this.modelo);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(41, 78, 617, 406);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		add(scrollPane); 
		
		scrollPane.setViewportView(table);
		
		btnVolver = new JButton("");
		btnVolver.addActionListener(this);
		btnVolver.setIcon(new ImageIcon(solicitudes_compra.class.getResource("/imagenes/19-add-cat_icon-icons.com_76695.png")));
		btnVolver.setBounds(50, 519, 65, 41);
		add(btnVolver);
		
		btnSalir = new JButton("");
		btnSalir.addActionListener(this);
		btnSalir.setIcon(new ImageIcon(solicitudes_compra.class.getResource("/imagenes/4115235-exit-logout-sign-out_114030.png")));
		btnSalir.setBounds(574, 519, 58, 41);
		add(btnSalir);
		
		btnEliminar = new JButton("");
		btnEliminar.addActionListener(this);
		btnEliminar.setIcon(new ImageIcon(solicitudes_compra.class.getResource("/imagenes/1-trash-cat_icon-icons.com_76677.png")));
		btnEliminar.setBounds(317, 519, 65, 41);
		add(btnEliminar);
		
		solicitudesBD();
	}
	private void solicitudesBD () {
	    modelo.setRowCount(0);

	    for (Object[] fila : GestionBaseDatos.solicitudes()) {
	        modelo.addRow(fila);
	    }
	}
	public void actionPerformed(ActionEvent e) {
		
		Object ob = e.getSource();
		
		if (ob.equals(btnSalir)) {
		        System.exit(0);
		    }
		 
		if (ob.equals(btnVolver)) {
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.setContentPane(new gerente("cargo"));
			    frame.revalidate();
			    frame.repaint();
			}
		 
		 if(ob.equals(btnEliminar)) {

			    int fila = table.getSelectedRow();

			    if(fila == -1){
			        JOptionPane.showMessageDialog(this, "Selecciona una fila");
			        return;
			    }

			    int id = (int) table.getValueAt(fila, 0); 

			    try {
			        Connection con = Conexion.getConexion();

			        PreparedStatement ps = con.prepareStatement(
			            "DELETE FROM solicitudes_compra WHERE id_solicitud = ?"
			        );

			        ps.setInt(1, id);
			        ps.executeUpdate();

			        modelo.removeRow(fila); 

			        con.close();

			        JOptionPane.showMessageDialog(this, "Eliminado correctamente");

			    } catch (Exception ex) {
			        ex.printStackTrace();
			    	}
				}
			}
}
