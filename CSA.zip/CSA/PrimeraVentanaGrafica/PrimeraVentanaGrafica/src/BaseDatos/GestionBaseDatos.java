package BaseDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;


import BaseDatos.Conexion;

	
	public class GestionBaseDatos {
	private DefaultTableModel modeloRefrescoV;
	private DefaultTableModel modeloLicoresV;
	 

		public void cargarBebidasDesdeBD(DefaultTableModel modelo) {

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery("SELECT * FROM refrescos");

		        modelo.setRowCount(0);

		        while (rs.next()) {
		            modelo.addRow(new Object[]{
		                rs.getInt("id_refrescos"),
		                rs.getString("nombre"),
		                rs.getString("stock"),
		                rs.getString("fecha_caducidad")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    		
		    	}
			}
		
		public void cargarLicoresDesdeBD(DefaultTableModel modelo) {

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery("SELECT * FROM licores");

		        modelo.setRowCount(0);

		        while (rs.next()) {
		            modelo.addRow(new Object[]{
		                rs.getInt("id_licor"),
		                rs.getString("nombre"),
		                rs.getString("stock"),
		                rs.getString("fecha_caducidad")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    		
		    	}
			}
		
		public void solicitudesBD(DefaultTableModel modelo) {

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery("SELECT * FROM solicitudes_compra");

		        modelo.setRowCount(0);

		        while (rs.next()) {
		            modelo.addRow(new Object[]{
		            		
		            			rs.getInt("id_solicitud"),
	            			    rs.getString("producto"),
	            			    rs.getString("cantidad"),
	            			    rs.getString("tipo"),
	            			    rs.getString("fecha_solicitud"),
	            			    rs.getString("proveedor"),
	            			    rs.getString("estado"),
	            			    rs.getString("monto_total")
		           
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    		
		    	}
			}

		public static List<Object[]> solicitudes() {
		    List<Object[]> lista = new ArrayList<>();

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery("SELECT * FROM solicitudes_compra");

		        while (rs.next()) {
		            lista.add(new Object[]{
		            		rs.getInt("id_solicitud"),
            			    rs.getString("producto"),
            			    rs.getString("cantidad"),
            			    rs.getString("tipo"),
            			    rs.getString("fecha_solicitud"),
            			    rs.getString("proveedor"),
            			    rs.getString("estado"),
            			    rs.getString("monto_total")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    }

		    return lista;
		}
		
		
		public static List<Object[]> obtenerLicores() {
		    List<Object[]> lista = new ArrayList<>();

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery("SELECT * FROM licores");

		        while (rs.next()) {
		            lista.add(new Object[]{
		                rs.getInt("id_licor"),
		                rs.getString("nombre"),
		                rs.getString("stock"),
		                rs.getString("fecha_caducidad")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    }

		    return lista;
		}
		
		public static List<Object[]> obtenerRefrescos() {
		    List<Object[]> lista = new ArrayList<>();

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery("SELECT * FROM refrescos");

		        while (rs.next()) {
		            lista.add(new Object[]{
		                rs.getInt("id_refrescos"),
		                rs.getString("nombre"),
		                rs.getString("stock"),
		                rs.getString("fecha_caducidad")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    }

		    return lista;
		}
		
		public static List<Object[]> obtenerRefrescosVencidos() {
		    List<Object[]> lista = new ArrayList<>();

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery(
		            "SELECT id_refrescos, nombre, stock, fecha_caducidad " +
		            "FROM refrescos " +
		            "WHERE fecha_caducidad < CURDATE() " +
		            "ORDER BY fecha_caducidad ASC"
		        );

		        while (rs.next()) {
		            lista.add(new Object[]{
		                rs.getInt("id_refrescos"),
		                rs.getString("nombre"),
		                rs.getString("stock"),
		                rs.getString("fecha_caducidad")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    }

		    return lista;
		}
		
		
		public static List<Object[]> obtenerLicoresVencidos() {
		    List<Object[]> lista = new ArrayList<>();

		    try {
		        Connection con = Conexion.getConexion();
		        Statement stmt = con.createStatement();

		        ResultSet rs = stmt.executeQuery(
		            "SELECT id_licor, nombre, stock, fecha_caducidad " +
		            "FROM licores " +
		            "WHERE fecha_caducidad < CURDATE() " +
		            "ORDER BY fecha_caducidad ASC"
		        );

		        while (rs.next()) {
		            lista.add(new Object[]{
		                rs.getInt("id_licor"),
		                rs.getString("nombre"),
		                rs.getString("stock"),
		                rs.getString("fecha_caducidad")
		            });
		        }

		        rs.close();
		        stmt.close();
		        con.close();

		    } catch (Exception ex) {
		        ex.printStackTrace();
		    }

		    return lista;
		}
				}
	 


