import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;

public class Logeo extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	private static final String URL_VERIFICAR = "http://localhost/licoreria/verificar_login.php";

	private static final javax.swing.border.Border BORDE_NORMAL = BorderFactory.createLineBorder(Color.GRAY);
	private static final javax.swing.border.Border BORDE_ERROR  = BorderFactory.createLineBorder(new Color(220, 50, 50), 2);
	private static final javax.swing.border.Border BORDE_OK     = BorderFactory.createLineBorder(new Color(50, 180, 50), 2);

	private JPanel         contentPane;
	private JTextField     tfNombre;
	private JPasswordField pfpass;
	private JComboBox      cbCargo;
	private JButton        btnLimpiar, btnEntrar, btnSalir;
	private JTable         table, table_1;
	private JLabel         lblImagen;
	private JLabel         lblErrorNombre, lblErrorPass, lblErrorCargo;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Logeo frame = new Logeo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Logeo() {
		setTitle("Ventana de Logeo");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// ── Labels ───────────────────────────────────────────────────────────
		JLabel lblNombre = new JLabel("USUARIO:");
		lblNombre.setForeground(Color.BLACK);
		lblNombre.setFont(new Font("HP Simplified Jpan", Font.BOLD, 20));
		lblNombre.setBounds(101, 186, 88, 20);
		contentPane.add(lblNombre);

		JLabel lblContraseña = new JLabel("CONTRASEÑA:");
		lblContraseña.setForeground(Color.BLACK);
		lblContraseña.setFont(new Font("HP Simplified Jpan", Font.BOLD, 20));
		lblContraseña.setBounds(101, 217, 152, 29);
		contentPane.add(lblContraseña);

		JLabel lblCargo = new JLabel("CARGO:");
		lblCargo.setForeground(Color.BLACK);
		lblCargo.setFont(new Font("HP Simplified Jpan", Font.BOLD, 20));
		lblCargo.setBounds(101, 256, 88, 29);
		contentPane.add(lblCargo);

		// ── Campos ───────────────────────────────────────────────────────────
		tfNombre = new JTextField();
		tfNombre.setForeground(Color.BLACK);
		tfNombre.setBounds(273, 185, 178, 20);
		tfNombre.setBorder(BORDE_NORMAL);
		tfNombre.setColumns(10);
		contentPane.add(tfNombre);

		pfpass = new JPasswordField();
		pfpass.setBounds(273, 219, 178, 20);
		pfpass.setBorder(BORDE_NORMAL);
		contentPane.add(pfpass);

		cbCargo = new JComboBox();
		cbCargo.setFont(new Font("Tahoma", Font.PLAIN, 11));
		cbCargo.setModel(new DefaultComboBoxModel(new String[] {
				"Seleccione una de las opciones", "Gerente", "Empleado" }));
		cbCargo.setEditable(false); // No editable: solo permite las opciones válidas
		cbCargo.setBounds(274, 249, 177, 22);
		contentPane.add(cbCargo);

		// ── Mensajes de error bajo cada campo ────────────────────────────────
		lblErrorNombre = crearLabelError(273, 206);
		lblErrorPass   = crearLabelError(273, 240);
		lblErrorCargo  = crearLabelError(273, 272);
		contentPane.add(lblErrorNombre);
		contentPane.add(lblErrorPass);
		contentPane.add(lblErrorCargo);

		// ── Al hacer foco, limpiar el error del campo ─────────────────────────
		tfNombre.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				tfNombre.setBorder(BORDE_NORMAL);
				lblErrorNombre.setVisible(false);
			}
		});
		pfpass.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				pfpass.setBorder(BORDE_NORMAL);
				lblErrorPass.setVisible(false);
			}
		});
		cbCargo.addFocusListener(new FocusAdapter() {
			public void focusGained(FocusEvent e) {
				cbCargo.setBorder(BORDE_NORMAL);
				lblErrorCargo.setVisible(false);
			}
		});

		// ── Separador ────────────────────────────────────────────────────────
		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(0, 102, 0));
		separator.setBounds(10, 309, 620, 8);
		contentPane.add(separator);

		// ── Botones ──────────────────────────────────────────────────────────
		btnSalir = new JButton("");
		btnSalir.setIcon(new ImageIcon(Logeo.class.getResource("/imagenes/4115235-exit-logout-sign-out_114030.png")));
		btnSalir.addActionListener(this);
		btnSalir.setBounds(544, 327, 49, 42);
		contentPane.add(btnSalir);

		btnEntrar = new JButton("");
		btnEntrar.setIcon(new ImageIcon(Logeo.class.getResource("/imagenes/7.png")));
		btnEntrar.setVerticalAlignment(SwingConstants.BOTTOM);
		btnEntrar.addActionListener(this);
		btnEntrar.setBounds(287, 327, 49, 42);
		contentPane.add(btnEntrar);

		btnLimpiar = new JButton("");
		btnLimpiar.setIcon(new ImageIcon(Logeo.class.getResource("/imagenes/1-trash-cat_icon-icons.com_76677.png")));
		btnLimpiar.addActionListener(this);
		btnLimpiar.setBounds(32, 327, 49, 42);
		contentPane.add(btnLimpiar);

		// ── Tablas decorativas ────────────────────────────────────────────────
		table = new JTable();
		table.setBackground(new Color(131, 174, 222));
		table.setBounds(85, 165, 168, 133);
		contentPane.add(table);

		table_1 = new JTable();
		table_1.setBackground(new Color(172, 169, 226));
		table_1.setBounds(246, 165, 244, 133);
		contentPane.add(table_1);

		// ── Imagen ────────────────────────────────────────────────────────────
		lblImagen = new JLabel("");
		lblImagen.setIcon(new ImageIcon(Logeo.class.getResource("/imagenes/9.png")));
		lblImagen.setBounds(215, 10, 152, 145);
		contentPane.add(lblImagen);
	}

	// ── Crea label de error rojo pequeño ─────────────────────────────────────
	private JLabel crearLabelError(int x, int y) {
		JLabel lbl = new JLabel("");
		lbl.setForeground(new Color(220, 50, 50));
		lbl.setFont(new Font("Tahoma", Font.BOLD, 10));
		lbl.setBounds(x, y, 200, 14);
		lbl.setVisible(false);
		return lbl;
	}

	// ── Eventos de botones ────────────────────────────────────────────────────
	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();

		if (ob.equals(btnSalir)) {
			System.exit(0);
		}

		if (ob.equals(btnLimpiar)) {
			tfNombre.setText("");
			pfpass.setText("");
			cbCargo.setSelectedIndex(0);
			// Resetear todos los bordes y errores
			tfNombre.setBorder(BORDE_NORMAL);
			pfpass.setBorder(BORDE_NORMAL);
			cbCargo.setBorder(BORDE_NORMAL);
			lblErrorNombre.setVisible(false);
			lblErrorPass.setVisible(false);
			lblErrorCargo.setVisible(false);
		}

		if (ob.equals(btnEntrar)) {

		    String nombre = tfNombre.getText();
		    String pass   = new String(pfpass.getPassword());
		    String cargo  = cbCargo.getSelectedItem().toString();

		    boolean hayError = false;

		    if (nombre == null || nombre.trim().isEmpty()) {
		        tfNombre.setBorder(BORDE_ERROR);
		        lblErrorNombre.setText("✖ Campo obligatorio");
		        lblErrorNombre.setVisible(true);
		        hayError = true;
		    } else {
		        tfNombre.setBorder(BORDE_OK);
		        lblErrorNombre.setVisible(false);
		    }

		    if (pass == null || pass.trim().isEmpty()) {
		        pfpass.setBorder(BORDE_ERROR);
		        lblErrorPass.setText("✖ Campo obligatorio");
		        lblErrorPass.setVisible(true);
		        hayError = true;
		    } else {
		        pfpass.setBorder(BORDE_OK);
		        lblErrorPass.setVisible(false);
		    }

		    if (cargo.equals("Seleccione una de las opciones")) {
		        cbCargo.setBorder(BORDE_ERROR);
		        lblErrorCargo.setText("✖ Selecciona un cargo");
		        lblErrorCargo.setVisible(true);
		        hayError = true;
		    } else {
		        cbCargo.setBorder(BORDE_OK);
		        lblErrorCargo.setVisible(false);
		    }

		    if (hayError) {
		        return;
		    }

		    btnEntrar.setEnabled(false);

		    final String nombreFinal = nombre.trim();
		    final String passFinal   = pass.trim();
		    final String cargoFinal  = cargo.trim();

		    new Thread(() -> {
		        String respuesta = consultarVerificacion(nombreFinal, passFinal, cargoFinal);
		        SwingUtilities.invokeLater(() -> procesarRespuesta(respuesta));
		    }).start();
		}

	}

	// ── Consulta al PHP: solo SELECT, nunca modifica la BD ───────────────────
	private String consultarVerificacion(String nombre, String pass, String cargo) {
	    try {
	        java.net.URL url = new java.net.URL(URL_VERIFICAR);
	        java.net.HttpURLConnection conn =
	                (java.net.HttpURLConnection) url.openConnection();

	        conn.setRequestMethod("POST");
	        conn.setDoOutput(true);
	        conn.setConnectTimeout(5000);
	        conn.setReadTimeout(5000);
	        conn.setRequestProperty(
	                "Content-Type",
	                "application/x-www-form-urlencoded"
	        );

	        String parametros =
	                "nombre=" + java.net.URLEncoder.encode(nombre, "UTF-8")
	                + "&clave=" + java.net.URLEncoder.encode(pass, "UTF-8")
	                + "&cargo=" + java.net.URLEncoder.encode(cargo, "UTF-8");

	        java.io.OutputStream os = conn.getOutputStream();
	        os.write(parametros.getBytes("UTF-8"));
	        os.flush();
	        os.close();

	        java.io.BufferedReader br = new java.io.BufferedReader(
	                new java.io.InputStreamReader(conn.getInputStream(), "UTF-8")
	        );

	        String respuesta = br.readLine();
	        br.close();

	        System.out.println("Respuesta PHP: " + respuesta);
	        return respuesta != null ? respuesta.trim() : "ERROR_CONEXION";

	    } catch (Exception ex) {
	        System.out.println("Error: " + ex.getMessage());
	        return "ERROR_CONEXION";
	    }
	}

	
	
	
	
	private void procesarRespuesta(String respuesta) {
	    btnEntrar.setEnabled(true);

	    if (respuesta == null) {
	        respuesta = "ERROR_CONEXION";
	    }

	    respuesta = respuesta.trim();

	    switch (respuesta) {
	    case "Gerente":
	    case "Empleado":
	        if (camposCompletos()) {
	            abrirPanelPrincipal(respuesta);
	        }
	        break;


	    case "ERROR_CONEXION":
	        JOptionPane.showMessageDialog(null,
	                "No se pudo conectar al servidor.\nVerifica que XAMPP esté activo.");
	        break;

	    case "CAMPOS_VACIOS":
	        JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
	        break;

	    case "CREDENCIALES_INVALIDAS":
	    default:
	        tfNombre.setBorder(BORDE_ERROR);
	        pfpass.setBorder(BORDE_ERROR);
	        cbCargo.setBorder(BORDE_ERROR);

	        lblErrorNombre.setText("✖ Datos incorrectos");
	        lblErrorPass.setText("✖ Datos incorrectos");
	        lblErrorCargo.setText("✖ Datos incorrectos");

	        lblErrorNombre.setVisible(true);
	        lblErrorPass.setVisible(true);
	        lblErrorCargo.setVisible(true);

	        JOptionPane.showMessageDialog(
	                null,
	                "Usuario, contraseña o cargo incorrectos"
	        );
	        break;
	    }
	}

	private boolean camposCompletos() {
	    String nombre = tfNombre.getText();
	    String pass = new String(pfpass.getPassword());
	    Object cargoSeleccionado = cbCargo.getSelectedItem();
	    String cargo = cargoSeleccionado != null ? cargoSeleccionado.toString() : "";

	    if (nombre == null || nombre.trim().isEmpty()
	            || pass == null || pass.trim().isEmpty()
	            || cargo.trim().isEmpty()
	            || cargo.equals("Seleccione una de las opciones")) {
	        JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
	        return false;
	    }

	    return true;
	}


	// ── Abre el panel según el cargo ──────────────────────────────────────────
	private void abrirPanelPrincipal(String cargoBD) {
	    if (!camposCompletos()) {
	        return;
	    }

		JFrame framePrincipal = new JFrame();
		framePrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framePrincipal.setExtendedState(JFrame.MAXIMIZED_BOTH);
		framePrincipal.setLocationRelativeTo(null);

		try {
			String clasePanel = cargoBD.equalsIgnoreCase("Gerente") ? "gerente" : "usuario";
			JPanel panel = (JPanel) Class.forName(clasePanel)
					.getConstructor(String.class)
					.newInstance(cargoBD);

			framePrincipal.setContentPane(panel);
			framePrincipal.setVisible(true);
			this.dispose();
		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(null, "No se pudo abrir el panel principal");
		}
	}
}
