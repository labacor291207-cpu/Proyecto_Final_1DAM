import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import java.awt.Color;

public class gerente extends JPanel implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JLabel lblBienvenido;
	private JButton btniNVENTARIO;
	private JButton btnSOLICITUD;
	private JButton btnVolver;
	private JButton btnSalir;
	private JButton btnVerS;
	private DefaultTableModel modelo;
	private String cargoUsuario;
	private JButton btnVTL;
	private JButton btnVTR;
	private JButton btnREFRESCOS_C;
	private JButton btnLICORES_C;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private DefaultTableModel modelorefresco;
	private DefaultTableModel modelolicor;
	

	/**
	 * Create the panel.
	 */
	 public gerente(String cargo) { 
	       
		this.cargoUsuario = cargo;
		setLayout(null);
		
		lblBienvenido = new JLabel("BIENVENIDO GERENTE");
		lblBienvenido.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 28));
		lblBienvenido.setBounds(124, 30, 317, 31);
		add(lblBienvenido);
		
		btniNVENTARIO = new JButton("REGISTRAR INVENTARIO");
		btniNVENTARIO.addActionListener(this);
		btniNVENTARIO.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btniNVENTARIO.setBounds(155, 91, 210, 29);
		add(btniNVENTARIO);
		
		btnSOLICITUD = new JButton("SOLICITUD DE COMPRA");
		btnSOLICITUD.addActionListener(this);
		btnSOLICITUD.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btnSOLICITUD.setBounds(155, 296, 210, 29);
		add(btnSOLICITUD);
		
		btnVolver = new JButton("");
		btnVolver.addActionListener(this);
		btnVolver.setIcon(new ImageIcon(gerente.class.getResource("/imagenes/19-add-cat_icon-icons.com_76695.png")));
		btnVolver.setBounds(20, 397, 65, 41);
		add(btnVolver);
		
		btnSalir = new JButton("");
		btnSalir.addActionListener(this);
		btnSalir.setIcon(new ImageIcon(gerente.class.getResource("/imagenes/4115235-exit-logout-sign-out_114030.png")));
		btnSalir.setBounds(445, 397, 65, 41);
		add(btnSalir);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(408, 60, 0, 2);
		add(separator);
		
		btnVerS = new JButton("TODAS LAS SOLICITUDES");
		btnVerS.addActionListener(this);
		btnVerS.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btnVerS.setBounds(155, 335, 208, 29);
		add(btnVerS);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(23, 385, 475, 2);
		add(separator_1);
		
		btnVTL = new JButton("VER TODOS LOS LICORES");
		btnVTL.addActionListener(this);
		btnVTL.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btnVTL.setBounds(155, 130, 210, 29);
		add(btnVTL);
		
		btnVTR = new JButton("VER TODOS LOS REFRESCOS");
		btnVTR.addActionListener(this);
		btnVTR.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btnVTR.setBounds(155, 169, 210, 29);
		add(btnVTR);
		
		btnREFRESCOS_C = new JButton("REFRESCOS CADUCADOS");
		btnREFRESCOS_C.addActionListener(this);
		btnREFRESCOS_C.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btnREFRESCOS_C.setBounds(155, 212, 210, 29);
		add(btnREFRESCOS_C);
		
		btnLICORES_C = new JButton("LICORES CADUCADOS");
		btnLICORES_C.addActionListener(this);
		btnLICORES_C.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 15));
		btnLICORES_C.setBounds(155, 251, 210, 29);
		add(btnLICORES_C);
		
		table = new JTable();
		table.setBackground(new Color(136, 208, 236));
		table.setBounds(121, 75, 276, 130);
		add(table);
		
		table_1 = new JTable();
		table_1.setBackground(new Color(244, 198, 89));
		table_1.setBounds(121, 199, 276, 87);
		add(table_1);
		
		table_2 = new JTable();
		table_2.setBackground(new Color(165, 137, 216));
		table_2.setBounds(121, 284, 276, 87);
		add(table_2);
		
	}
	public void actionPerformed(ActionEvent e) {
		
		Object ob = e.getSource();
		 if(ob.equals(btnVolver)) {
			    Logeo ventana = new Logeo();
			    ventana.setVisible(true);

			    
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.dispose();
					}
		 if (ob.equals(btnSalir)) {
		        System.exit(0);
		    }
		 
		 if (ob.equals(btnSOLICITUD)) {
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.setContentPane(new solicitud_compra());
			    frame.revalidate();
			    frame.repaint();
						}
		 
		 if(ob.equals(btniNVENTARIO)) {
			    registro_inventario ventana = new registro_inventario("gerente");
			    ventana.setVisible(true);

			    
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.dispose();
					}
		 
		 if (ob.equals(btnVerS)) {
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.setContentPane(new solicitudes_compra(modelo));
			    frame.revalidate();
			    frame.repaint();
					}
		 
		 if (ob.equals(btnREFRESCOS_C)) {
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.setContentPane(new refrescos_vencidos("gerente"));
			    frame.revalidate();
			    frame.repaint();
						}
			
		 if (ob.equals(btnLICORES_C)) {
		    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
		    frame.setContentPane(new licores_vencidos("gerente"));
		    frame.revalidate();
		    frame.repaint();
					}
		 
		 if (ob.equals(btnVTL)) {
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.setContentPane(new licores_registro(modelolicor, cargoUsuario)); 
			    frame.revalidate();
			    frame.repaint();
			}
		 
		 if (ob.equals(btnVTR)) {
			    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			    frame.setContentPane(new refrescos_registro(modelorefresco, cargoUsuario)); 
			    frame.revalidate();
			    frame.repaint();
			}
		}
}
