import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import BaseDatos.Conexion;
import BaseDatos.GestionBaseDatos;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class refrescos_vencidos extends JPanel implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblrefrescosC;
	private DefaultTableModel modeloRefrescoV;
	private String [] datos = new String [4];
	private String cargoUsuario;
	private JButton btnVolver;
	private JButton btnSalir;
	private JButton btnBorrar;
	
	/**
	 * Create the panel.
	 */
	
	public refrescos_vencidos(String cargo) {
      
		this.cargoUsuario = cargo; 
		
		setLayout(null);
		
		modeloRefrescoV = new DefaultTableModel(
			    new String[]{"ID", "Nombre", "Stock", "Fecha Caducidad"}, 0
			);
		
		lblrefrescosC = new JLabel("REFRESCOS VENCIDOS");
		lblrefrescosC.setFont(new Font("Rockwell Nova Cond", Font.BOLD, 24));
		lblrefrescosC.setBounds(160, 32, 238, 32);
		add(lblrefrescosC);
		
		table = new JTable(modeloRefrescoV);
		
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(38, 81, 471, 235);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		add(scrollPane); 
		
		btnVolver = new JButton("");
		btnVolver.addActionListener(this);
		btnVolver.setIcon(new ImageIcon(refrescos_vencidos.class.getResource("/imagenes/19-add-cat_icon-icons.com_76695.png")));
		btnVolver.setBounds(38, 371, 65, 32);
		add(btnVolver);
		
		btnSalir = new JButton("");
		btnSalir.addActionListener(this);
		btnSalir.setIcon(new ImageIcon(refrescos_vencidos.class.getResource("/imagenes/4115235-exit-logout-sign-out_114030.png")));
		btnSalir.setBounds(437, 371, 65, 32);
		add(btnSalir);
		
		btnBorrar = new JButton("");
		btnBorrar.addActionListener(this);
		btnBorrar.setIcon(new ImageIcon(refrescos_vencidos.class.getResource("/imagenes/1-trash-cat_icon-icons.com_76677.png")));
		btnBorrar.setBounds(243, 371, 65, 32);
		add(btnBorrar);
		
		cargarCaducadosDesdeBD();
	}

	private void cargarCaducadosDesdeBD() {
	    modeloRefrescoV.setRowCount(0);

	    for (Object[] fila : GestionBaseDatos.obtenerRefrescosVencidos()) {
	        modeloRefrescoV.addRow(fila);
	    }
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		 Object ob = e.getSource();
		
		 if (ob.equals(btnVolver)) {
	          
	            JFrame framePrincipal = (JFrame) SwingUtilities.getWindowAncestor(this);

	            if (cargoUsuario.equalsIgnoreCase("Gerente")) {
	                framePrincipal.setContentPane(new gerente(cargoUsuario));
	            } else {
	                framePrincipal.setContentPane(new usuario(cargoUsuario));
	            }

	            framePrincipal.revalidate(); 
	            framePrincipal.repaint();
	        }

	        if (ob.equals(btnSalir)) {
	            System.exit(0); 
	        }
	        
	        if(ob.equals(btnBorrar)) {

			    int fila = table.getSelectedRow();

			    if(fila == -1){
			        JOptionPane.showMessageDialog(this, "Selecciona una fila");
			        return;
			    }

			    int id = (int) table.getValueAt(fila, 0); 

			    try {
			        Connection con = Conexion.getConexion();

			        PreparedStatement ps = con.prepareStatement(
			            "DELETE FROM refrescos WHERE id_refrescos = ?"
			        );

			        ps.setInt(1, id);
			        ps.executeUpdate();

			        modeloRefrescoV.removeRow(fila); 

			        con.close();

			        JOptionPane.showMessageDialog(this, "Eliminado correctamente");

			    } catch (Exception ex) {
			        ex.printStackTrace();
			    	}
				}
	    }
	}
		
		
		
	
	

