-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-05-2026 a las 02:37:16
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `licoreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id_empleado` int(11) NOT NULL,
  `id_personal_aux` int(11) NOT NULL,
  `turno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gerentes`
--

CREATE TABLE `gerentes` (
  `id_gerente` int(11) NOT NULL,
  `id_personal_aux` int(11) NOT NULL,
  `cargo` varchar(50) DEFAULT 'Gerencia General'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `licores`
--

CREATE TABLE `licores` (
  `id_licor` int(11) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `fecha_caducidad` date DEFAULT NULL,
  `stock` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `licores`
--

INSERT INTO `licores` (`id_licor`, `nombre`, `fecha_caducidad`, `stock`) VALUES
(7, 'negrita', '2029-01-11', 13),
(8, 'eristoff', '2027-04-12', 5),
(14, 'Puerto de indias', '2028-04-12', 45);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE `personal` (
  `id_Personal` int(11) NOT NULL,
  `usuario` varchar(30) DEFAULT NULL,
  `contraseña` varchar(30) DEFAULT NULL,
  `cargo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`id_Personal`, `usuario`, `contraseña`, `cargo`) VALUES
(1, 'celeste', '12345', 'gerente'),
(2, 'Axel', '123456', 'empleado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `refrescos`
--

CREATE TABLE `refrescos` (
  `id_refrescos` int(11) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `fecha_caducidad` date DEFAULT NULL,
  `stock` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `refrescos`
--

INSERT INTO `refrescos` (`id_refrescos`, `nombre`, `fecha_caducidad`, `stock`) VALUES
(1, 'coca cola', '2026-05-24', 32),
(2, 'fanta naranja', '2028-11-02', 23),
(6, 'nestea', '2027-04-22', 23);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_inventario`
--

CREATE TABLE `registro_inventario` (
  `id_registro` int(11) NOT NULL,
  `id_empleado_aux` int(11) DEFAULT NULL,
  `id_refrescos_aux` int(11) DEFAULT NULL,
  `id_licor_aux` int(11) DEFAULT NULL,
  `cantidad_ingresada` int(11) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes_compra`
--

CREATE TABLE `solicitudes_compra` (
  `id_solicitud` int(11) NOT NULL,
  `id_gerente_aux` int(11) DEFAULT NULL,
  `proveedor` varchar(100) DEFAULT NULL,
  `monto_total` decimal(12,2) DEFAULT NULL,
  `fecha_solicitud` date DEFAULT NULL,
  `estado` enum('Pendiente','Aprobado','Recibido') DEFAULT 'Pendiente',
  `producto` varchar(50) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `solicitudes_compra`
--

INSERT INTO `solicitudes_compra` (`id_solicitud`, `id_gerente_aux`, `proveedor`, `monto_total`, `fecha_solicitud`, `estado`, `producto`, `tipo`, `cantidad`) VALUES
(1, NULL, 'asd', 100.00, '2026-05-01', 'Aprobado', 'negrita', 'LICOR', 10),
(2, NULL, 'asdf', 89.00, '2026-05-04', 'Aprobado', 'Agua', 'REFRESCO', 12),
(3, NULL, 'asdfg', 199.00, '2026-05-05', 'Aprobado', 'Agua', 'REFRESCO', 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `clave` varchar(100) DEFAULT NULL,
  `cargo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `clave`, `cargo`) VALUES
(32, 'Axel', '123456789', 'Gerente'),
(44, 'Santiago', '1234567890', 'Empleado'),
(49, 'Celeste', '1234567890', 'Gerente'),
(61, 'Miller', '1234567890', 'Gerente'),
(62, 'Raul', '12345678900', 'Empleado'),
(63, 'Pedro', '12980234790832789', 'Empleado');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id_empleado`),
  ADD UNIQUE KEY `id_personal_aux` (`id_personal_aux`);

--
-- Indices de la tabla `gerentes`
--
ALTER TABLE `gerentes`
  ADD PRIMARY KEY (`id_gerente`),
  ADD UNIQUE KEY `id_personal_aux` (`id_personal_aux`);

--
-- Indices de la tabla `licores`
--
ALTER TABLE `licores`
  ADD PRIMARY KEY (`id_licor`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`id_Personal`);

--
-- Indices de la tabla `refrescos`
--
ALTER TABLE `refrescos`
  ADD PRIMARY KEY (`id_refrescos`);

--
-- Indices de la tabla `registro_inventario`
--
ALTER TABLE `registro_inventario`
  ADD PRIMARY KEY (`id_registro`),
  ADD KEY `id_empleado_aux` (`id_empleado_aux`),
  ADD KEY `id_refrescos_aux` (`id_refrescos_aux`),
  ADD KEY `id_licor_aux` (`id_licor_aux`);

--
-- Indices de la tabla `solicitudes_compra`
--
ALTER TABLE `solicitudes_compra`
  ADD PRIMARY KEY (`id_solicitud`),
  ADD KEY `id_gerente_aux` (`id_gerente_aux`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id_empleado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `gerentes`
--
ALTER TABLE `gerentes`
  MODIFY `id_gerente` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `licores`
--
ALTER TABLE `licores`
  MODIFY `id_licor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `id_Personal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `refrescos`
--
ALTER TABLE `refrescos`
  MODIFY `id_refrescos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `registro_inventario`
--
ALTER TABLE `registro_inventario`
  MODIFY `id_registro` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `solicitudes_compra`
--
ALTER TABLE `solicitudes_compra`
  MODIFY `id_solicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`id_personal_aux`) REFERENCES `personal` (`id_Personal`) ON DELETE CASCADE;

--
-- Filtros para la tabla `gerentes`
--
ALTER TABLE `gerentes`
  ADD CONSTRAINT `gerentes_ibfk_1` FOREIGN KEY (`id_personal_aux`) REFERENCES `personal` (`id_Personal`) ON DELETE CASCADE;

--
-- Filtros para la tabla `registro_inventario`
--
ALTER TABLE `registro_inventario`
  ADD CONSTRAINT `registro_inventario_ibfk_1` FOREIGN KEY (`id_empleado_aux`) REFERENCES `empleados` (`id_empleado`),
  ADD CONSTRAINT `registro_inventario_ibfk_2` FOREIGN KEY (`id_refrescos_aux`) REFERENCES `refrescos` (`id_refrescos`),
  ADD CONSTRAINT `registro_inventario_ibfk_3` FOREIGN KEY (`id_licor_aux`) REFERENCES `licores` (`id_licor`);

--
-- Filtros para la tabla `solicitudes_compra`
--
ALTER TABLE `solicitudes_compra`
  ADD CONSTRAINT `solicitudes_compra_ibfk_1` FOREIGN KEY (`id_gerente_aux`) REFERENCES `gerentes` (`id_gerente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
